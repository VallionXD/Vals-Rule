const decodeValsRule = (pattern, encodedString) => {
    // Split the pattern to get the randomized strings, and the length of them.
    const cleanedPattern = pattern.replace(/Val-|\(\d+\)|_/g, '');

    // Extract the randomized strings.
    const regex = /([a-zA-Z\d]+)/g;
    const matches = cleanedPattern.match(regex);

    // Create an array with the randomized strings, to use in decoding.
    const randomizedStrings = matches ? matches : [];
    let cleanedString = encodedString;
    
    // Iterate through each randomizedString and check if it's present in encodedString
    randomizedStrings.forEach(randomizedString => {
        // If the encodedString contains the randomizedString
        cleanedString = cleanedString.split(randomizedString).join('');
    });

    // Return the cleanedString
    return cleanedString;
}

// Set your pattern and encoded string, use the decoder, and log the result in the console
let pattern = "Val-v88W4V-a9sZ3d-b6tY7u-c5xX2z-d4wW1q-e3vV8r-f2uU9s-g1tT0y-h7sS5x-i6rR4v-(6)";
let encodedString = "Lf2uU9soa9sZ3drd4wW1qeb6tY7umc5xX2z c5xX2ziv88W4Vpv88W4Vsh7sS5xuc5xX2zmc5xX2z v88W4Vdd4wW1qoi6rR4vlv88W4Voc5xX2zra9sZ3d c5xX2zse3vV8rii6rR4vth7sS5x g1tT0yai6rR4vmh7sS5xef2uU9st";
let decodedString = decodeValsRule(pattern, encodedString);
console.log(decodedString);